<?php

namespace Rayku\TutorBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class RaykuTutorBundle extends Bundle
{
}
